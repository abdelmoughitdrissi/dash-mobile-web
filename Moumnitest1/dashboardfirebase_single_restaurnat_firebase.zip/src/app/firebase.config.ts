
export const firebaseConfig = {
  apiKey: "AIzaSyA9tJ1p8iDcYy6tLoOisnr4zXFbS8aHEag",
  authDomain: "restaurant-1440e.firebaseapp.com",
  databaseURL: "https://restaurant-1440e.firebaseio.com",
  storageBucket: "restaurant-1440e.appspot.com",
  messagingSenderId: "314198464457"

};

export const firebaseConfigTwo = {
  apiKey: "AIzaSyA9tJ1p8iDcYy6tLoOisnr4zXFbS8aHEag",
  authDomain: "restaurant-1440e.firebaseapp.com",
  databaseURL: "https://restaurant-1440e.firebaseio.com",
  storageBucket: "restaurant-1440e.appspot.com",
  messagingSenderId: "314198464457"

};

export const cloudinarUpload = {
  cloudName: 'pietechsolutions',
  uploadPreset: 't0iey0lk'
};


