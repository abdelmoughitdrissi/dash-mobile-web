// counter.ts
import { ActionReducer, Action } from '@ngrx/store';


export function chatData(state: string='hello', action: Action) {
	  		
	  		return action.type; 
	  		
}